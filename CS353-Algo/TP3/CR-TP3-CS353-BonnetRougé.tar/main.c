/******************************************************************************
 * Programme de test du gestionnaire de magasin                               *                                                               *
 ******************************************************************************/

#include "store.h"
#include <stdio.h>


int main()
{
    //
    printf("****** Gestionnaire de magasin ******\n");
    init();
    //
    printf("=======Gestionnaire de magasin ======\n");

    return 0;
}

