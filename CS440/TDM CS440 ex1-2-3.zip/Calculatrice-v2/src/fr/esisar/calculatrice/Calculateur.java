package fr.esisar.calculatrice;

/* --- Réponse aux questions ---

1. java -version et javac -version 		
clic droit > Build Path > Configuration Build Path -> Libraries -> Add Library -> JRE System Library

2. OK

3. Le type int est un type primitif avec qu'Integer est une classe wrapper

4.
javac -d classes/ src/fr/esisar/calculatrice/*.java
jar cfe calculatrice-1.0.jar fr.esisar.calculatrice.Calculateur -C classes/ .
java -jar calculatrice-1.0.ja
*/

public class Calculateur {

	public static void main(String[] args) {

		Calculatrice calcu = new Calculatrice();

		Integer a = 2;
		Integer b = 2;
		Integer c = 0;

		try {
		calcu.calculer("Ajouter", a, b);
		calcu.calculer("Soustraire", a, b);
		calcu.calculer("Multiplier", a, b);
		calcu.calculer("Diviser", a, b);
		calcu.calculer("Diviser", a, c);
		} catch (Exception e) {	System.out.println(e);	}
	}
}
