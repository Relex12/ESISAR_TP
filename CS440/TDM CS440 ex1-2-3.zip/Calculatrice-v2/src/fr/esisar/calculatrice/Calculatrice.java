package fr.esisar.calculatrice;

import java.util.ArrayList;
import java.util.List;

import fr.esisar.calculatrice.operations.*;

public class Calculatrice {
	
	private List<Operation> operations ;
	
	public Calculatrice() {
		this.operations = new ArrayList<Operation>();
		operations.add(new Ajouter());
		operations.add(new Diviser());
		operations.add(new Multiplier());
		operations.add(new Soustraire());
	}
	
	public Operation chercherOperation(String nom) {
		for(Operation op : operations) {
			if(op.getNom().equals(nom)) {
				return op;
			}
		}
		return null;
	}
	
	public double calculer(String operation, double op1, double op2) throws OperationInvalide {
		Operation op = chercherOperation(operation);
		if(op == null) {
			throw new OperationInvalide("Opération non trouvée");	
		}
		return op.calculer(op1, op2);
	}

}
