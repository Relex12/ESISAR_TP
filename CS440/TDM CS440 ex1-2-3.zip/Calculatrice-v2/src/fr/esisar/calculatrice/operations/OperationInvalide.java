package fr.esisar.calculatrice.operations;

public class OperationInvalide extends Exception {

	private static final long serialVersionUID = 8375836348828653904L;
	private String message = "L'opération est invalide.";
	
	public OperationInvalide(String error) {
		message = error;
	}
	
	public String toString() {
		return message;
	}

}
