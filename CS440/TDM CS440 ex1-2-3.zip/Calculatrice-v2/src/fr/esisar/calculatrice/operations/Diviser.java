package fr.esisar.calculatrice.operations;

public class Diviser implements Operation {

	@Override
	public String getNom() {
		return "Diviser";
	}

	@Override
	public double calculer(double op1, double op2) throws OperationInvalide {
		if (op2 == 0) throw new OperationInvalide("Division par 0");
		return (op1 / op2);
	}
}
