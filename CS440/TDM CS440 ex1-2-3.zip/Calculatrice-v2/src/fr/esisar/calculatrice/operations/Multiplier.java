package fr.esisar.calculatrice.operations;

public class Multiplier implements Operation {

	@Override
	public String getNom() {
		return "Multiplier";
	}

	@Override
	public double calculer(double op1, double op2) {
		return (op1 * op2);
	}
}
