package fr.esisar.calculatrice.operations;

public interface Operation {

	public String getNom ();
	public double calculer (double op1, double op2) throws OperationInvalide;
}
