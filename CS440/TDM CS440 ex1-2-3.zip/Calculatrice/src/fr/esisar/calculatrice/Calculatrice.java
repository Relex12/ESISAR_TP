package fr.esisar.calculatrice;

public class Calculatrice {
	
	public Integer ajouter (Integer operande1, Integer operande2) {
		return operande1 + operande2;	
	}

	public Integer soustraire (Integer operande1, Integer operande2) {
		return operande1 - operande2;	
	}

	public Integer multiplier (Integer operande1, Integer operande2) {
		return operande1 * operande2;	
	}

	public Double diviser (Integer operande1, Integer operande2) throws ArithmeticException {
		if (operande2 == 0) throw new ArithmeticException();
		
		return operande1.doubleValue() / operande2.doubleValue();		
	}

}
