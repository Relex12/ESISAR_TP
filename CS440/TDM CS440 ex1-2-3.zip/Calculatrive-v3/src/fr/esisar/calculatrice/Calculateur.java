package fr.esisar.calculatrice;

import fr.esisar.calculatrice.operations.OperationInvalide;
import fr.esisar.calculatrice.operations.binaires.*;
import fr.esisar.calculatrice.operations.unaires.*;
import fr.esisar.calculatrice.operations.ensemblistes.*;

public class Calculateur {

	public static void main(String[] args) {

		System.out.println("Création de la calculatrice...");
		Calculatrice calc = new Calculatrice();

		System.out.println("Ajout de l'opération Ajouter");
		calc.ajouterOperation(new Ajouter());
		System.out.println("Ajout de l'opération Soustraire");
		calc.ajouterOperation(new Soustraire());
		System.out.println("Ajout de l'opération Multiplier");
		calc.ajouterOperation(new Multiplier());
		System.out.println("Ajout de l'opération Diviser");
		calc.ajouterOperation(new Diviser());

		System.out.println("Ajout de l'opération Diviser (seconde fois)");
		Diviser diviser = new Diviser();
		calc.ajouterOperation(diviser);
		System.out.println("Suppression de la seconde opération Diviser");
		calc.retirerOperation(diviser);

		System.out.println("Ajout de l'opération Cosinus");
		calc.ajouterOperation(new Cosinus());
		System.out.println("Ajout de l'opération Sinus");
		calc.ajouterOperation(new Sinus());
		System.out.println("Ajout de l'opération Tangente");
		calc.ajouterOperation(new Tangente());
		System.out.println("Ajout de l'opération Valeur Absolue");
		calc.ajouterOperation(new ValeurAbsolue());

		System.out.println("Ajout de l'opération Maximum");
		calc.ajouterOperation(new Maximum());
		System.out.println("Ajout de l'opération Minimum");
		calc.ajouterOperation(new Minimum());

		System.out.println("Fin de la création de la calculatrice.\n");

		System.out.println("== Test des opérations binaires ==");
		try {
			System.out.println("3 + 6 = " + calc.calculer("Soustraire", 3, 6));
		} catch (OperationInvalide e) {
			e.printStackTrace();
		}
		try {
			System.out.println("3 - 6 = " + calc.calculer("Ajouter", 3, 6));
		} catch (OperationInvalide e) {
			e.printStackTrace();
		}
		try {
			System.out.println("3 * -5 = " + calc.calculer("Multiplier", 3, -5));
		} catch (OperationInvalide e) {
			e.printStackTrace();
		}
		try {
			System.out.println("3 / 3 = " + calc.calculer("Diviser", 3, 3));
		} catch (OperationInvalide e) {
			e.printStackTrace();
		}
		try {
			System.out.println("6 / 0 = " + calc.calculer("Diviser", 6, 0));
		} catch (OperationInvalide e) {
			e.printStackTrace();
		}
		System.out.println("== Fin du test des opérations binaires ==\n\n");

	}
}
