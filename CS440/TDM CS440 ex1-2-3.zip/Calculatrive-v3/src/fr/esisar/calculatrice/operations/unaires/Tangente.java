package fr.esisar.calculatrice.operations.unaires;

import fr.esisar.calculatrice.operations.OperationInvalide;
import fr.esisar.calculatrice.operations.OperationUnaire;

public class Tangente extends OperationUnaire {

	@Override
	public String getNom() {
		return "Tangente";
	}

	@Override
	protected double doCalculer(double op1) throws OperationInvalide {
		if (java.lang.Math.cos(op1) == 0) throw new OperationInvalide("Tangente impossible");
		return java.lang.Math.tan(op1);
	}

}
