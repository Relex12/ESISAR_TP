package fr.esisar.calculatrice.operations.ensemblistes;

import fr.esisar.calculatrice.operations.OperationEnsembliste;

public class Maximum extends OperationEnsembliste {

	@Override
	public String getNom() {
		return "Maximum";
	}

	@Override
	protected double doCalculer(double... operandes) {
		double max = operandes[0];
	    for(int i=1; i<operandes.length; i++){
	    	if(operandes[i] > max) max = operandes[i];
		}
		return max;
	}

}
