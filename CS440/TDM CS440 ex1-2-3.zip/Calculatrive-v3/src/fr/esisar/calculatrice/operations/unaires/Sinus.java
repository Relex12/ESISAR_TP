package fr.esisar.calculatrice.operations.unaires;

import fr.esisar.calculatrice.operations.OperationUnaire;

public class Sinus extends OperationUnaire {

	@Override
	public String getNom() {
		return "Sinus";
	}

	@Override
	protected double doCalculer(double op1) {
		return java.lang.Math.sin(op1);
	}

}
