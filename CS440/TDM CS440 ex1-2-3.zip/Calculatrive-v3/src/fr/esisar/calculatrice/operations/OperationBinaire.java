package fr.esisar.calculatrice.operations;

public abstract class OperationBinaire implements Operation {

	@Override
	public double calculer(double... operandes) throws OperationInvalide{
		if (operandes.length != 2) throw new OperationInvalide("Deux arguments attendus");
		return doCalculer (operandes[0], operandes[1]);
	}

	protected abstract double doCalculer (double op1, double op2) throws OperationInvalide;
}
