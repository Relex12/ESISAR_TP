package fr.esisar.calculatrice.operations.unaires;

import fr.esisar.calculatrice.operations.OperationUnaire;

public class Cosinus extends OperationUnaire {

	@Override
	public String getNom() {
		return "Cosinus";
	}

	@Override
	protected double doCalculer(double op1) {
		return java.lang.Math.cos(op1);
	}

}
