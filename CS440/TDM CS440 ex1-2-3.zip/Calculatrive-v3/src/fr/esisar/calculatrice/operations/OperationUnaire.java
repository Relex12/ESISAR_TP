package fr.esisar.calculatrice.operations;

public abstract class OperationUnaire implements Operation {

	@Override
	public double calculer(double... operandes) throws OperationInvalide{
		if (operandes.length != 1) throw new OperationInvalide("Un seul argument attendu");
		return doCalculer (operandes[0]);
	}

	protected abstract double doCalculer (double op1) throws OperationInvalide;
}
