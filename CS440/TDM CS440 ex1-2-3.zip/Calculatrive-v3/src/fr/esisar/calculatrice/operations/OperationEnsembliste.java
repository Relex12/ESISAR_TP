package fr.esisar.calculatrice.operations;

public abstract class OperationEnsembliste implements Operation {

	@Override
	public double calculer(double... operandes) throws OperationInvalide{
		if (operandes.length == 0) throw new OperationInvalide("Deux arguments attendus");
		return doCalculer (operandes);
	}

	protected abstract double doCalculer(double ... operandes);

}
