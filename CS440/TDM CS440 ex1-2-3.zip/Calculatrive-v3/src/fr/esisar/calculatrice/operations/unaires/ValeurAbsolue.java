package fr.esisar.calculatrice.operations.unaires;

import fr.esisar.calculatrice.operations.OperationUnaire;

public class ValeurAbsolue extends OperationUnaire {

	@Override
	public String getNom() {
		return "ValeurAbsolue";
	}

	@Override
	protected double doCalculer(double op1) {
		return java.lang.Math.abs(op1);
	}

}
