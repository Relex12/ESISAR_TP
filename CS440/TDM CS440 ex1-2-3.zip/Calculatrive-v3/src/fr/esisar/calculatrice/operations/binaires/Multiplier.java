package fr.esisar.calculatrice.operations.binaires;

import fr.esisar.calculatrice.operations.OperationBinaire;

public class Multiplier extends OperationBinaire {

	@Override
	public String getNom() {
		return "Multiplier";
	}

	@Override
	protected double doCalculer(double op1, double op2) {
		return op1*op2;
	}

}
