package fr.esisar.calculatrice.operations.binaires;

import fr.esisar.calculatrice.operations.OperationBinaire;
import fr.esisar.calculatrice.operations.OperationInvalide;

public class Diviser extends OperationBinaire {

	@Override
	public String getNom() {
		return "Diviser";
	}

	@Override
	protected double doCalculer(double op1, double op2) throws OperationInvalide {
		if (op2 == 0) throw new OperationInvalide("Division par 0");
		return (op1 / op2);
	}
}
