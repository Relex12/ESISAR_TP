package fr.esisar.calculatrice.operations.ensemblistes;

import fr.esisar.calculatrice.operations.OperationEnsembliste;

public class Minimum extends OperationEnsembliste {

	@Override
	public String getNom() {
		return "Minimum";
	}

	@Override
	protected double doCalculer(double... operandes) {
		double min = operandes[0];
	    for(int i=1; i<operandes.length; i++){
	    	if(operandes[i] < min) min = operandes[i];
		}
		return min;
	}

}
