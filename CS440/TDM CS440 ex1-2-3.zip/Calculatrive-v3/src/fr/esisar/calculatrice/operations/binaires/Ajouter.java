package fr.esisar.calculatrice.operations.binaires;

import fr.esisar.calculatrice.operations.OperationBinaire;

public class Ajouter extends OperationBinaire {

	@Override
	public String getNom() {
		return "Ajouter";
	}

	@Override
	protected double doCalculer(double op1, double op2) {
		return op1+op2;
	}

}
