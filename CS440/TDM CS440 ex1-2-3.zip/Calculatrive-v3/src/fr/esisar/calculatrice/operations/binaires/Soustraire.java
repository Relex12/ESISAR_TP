package fr.esisar.calculatrice.operations.binaires;

import fr.esisar.calculatrice.operations.OperationBinaire;

public class Soustraire extends OperationBinaire {

	@Override
	public String getNom() {
		return "Soustraire";
	}

	@Override
	protected double doCalculer(double op1, double op2) {
		return op1-op2;
	}

}
