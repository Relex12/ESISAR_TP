package fr.esisar.calculatrice;

import java.util.ArrayList;
import java.util.List;

import fr.esisar.calculatrice.operations.*;

public class Calculatrice {
	
	private List<Operation> operations ;
		
	public Calculatrice() {
		operations = new ArrayList<Operation>();
	}
	
	public Operation chercherOperation(String nom) {
		for(Operation op : operations) {
			if(op.getNom().equals(nom)) {
				return op;
			}
		}
		return null;
	}
	
	public void ajouterOperation(Operation operation) {
		operations.add(operation);
	}
	
	public void retirerOperation(Operation operation) {
		operations.remove(operation);
	}
	
	public double calculer(String nom, double... operandes) throws OperationInvalide {
		Operation operation = chercherOperation(nom);
		if(operation == null) throw new OperationInvalide("Cette opération n'est pas connue");
		return operation.calculer(operandes);
	}

}
