public interface Nutrition
{
	public int getKcal();
	public float getGlucides();
}
