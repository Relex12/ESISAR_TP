public interface Consommable
{
	public String getNom();
	public int getPrix();
}
