public class CM extends Activite{
	public CM(String nom){
		super(nom);
	}
	
	public void addSalle(SalleCTD s){
		super.addSalle(s);
	}
}
