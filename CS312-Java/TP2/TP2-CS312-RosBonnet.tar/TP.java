
public class TP extends Activite{
	public TP(String nom){
		super(nom);
	}
	
	public void addSalle(SalleTP s){
		super.addSalle(s);
	}
}
