#include <stdio.h>
#include <stdlib.h>

int regitre[32];
int PC;
int HO;
int LI;

int lectureReg (int regitreVal);
void ecritureReg (int regitreVal);
int conversionNomVal (int registreNom); 	// renvoie la valeur du registre
