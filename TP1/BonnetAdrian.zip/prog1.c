#include <stdio.h>

int main() {
	printf("Bonjour \n");

/*  \n signifie "passage � la ligne" */

	return (0);
}